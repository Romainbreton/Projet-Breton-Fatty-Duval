<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

require_login();
$userId = (int)$_SESSION['user']['id'];

require_once __DIR__ . '/header.php';

/* Likes reçus sur mes citations */
$st = $pdo->prepare("
  SELECT COUNT(cl.id) AS total_likes_received
  FROM citations c
  LEFT JOIN citation_likes cl ON cl.citation_id = c.id
  WHERE c.created_by = :uid
");
$st->execute([':uid' => $userId]);
$totalLikesReceived = (int)($st->fetch()['total_likes_received'] ?? 0);

/* Mes citations + compteur likes */
$st = $pdo->prepare("
  SELECT c.id, c.texte, c.auteur, c.created_at, c.updated_at, COUNT(cl.id) AS likes_count
  FROM citations c
  LEFT JOIN citation_likes cl ON cl.citation_id = c.id
  WHERE c.created_by = :uid
  GROUP BY c.id
  ORDER BY c.created_at DESC
");
$st->execute([':uid' => $userId]);
$myCitations = $st->fetchAll();

/* Citations que j'ai likées */
$st = $pdo->prepare("
  SELECT
    c.id, c.texte, c.auteur, c.created_at,
    COUNT(cl2.id) AS likes_count,
    cl.created_at AS liked_at
  FROM citation_likes cl
  INNER JOIN citations c ON c.id = cl.citation_id
  LEFT JOIN citation_likes cl2 ON cl2.citation_id = c.id
  WHERE cl.user_id = :uid
  GROUP BY c.id, cl.created_at
  ORDER BY cl.created_at DESC
");
$st->execute([':uid' => $userId]);
$likedCitations = $st->fetchAll();
?>

<h2>Profil</h2>

<p>Compte : <strong><?= htmlspecialchars($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8') ?></strong></p>
<p>Rôle : <strong><?= htmlspecialchars($_SESSION['user']['role'], ENT_QUOTES, 'UTF-8') ?></strong></p>
<p><strong>Likes reçus :</strong> <?= $totalLikesReceived ?></p>

<hr>

<h3>Mes citations</h3>
<p><a href="/citation/my_citation_add.php">Ajouter une citation</a></p>

<?php if (!$myCitations): ?>
  <p>Aucune citation.</p>
<?php else: ?>
  <?php foreach ($myCitations as $c): ?>
    <?php
      $auteur = trim((string)($c['auteur'] ?? ''));
      if ($auteur === '') $auteur = 'Auteur inconnu';
    ?>
    <article>
      <div><strong><?= (int)$c['likes_count'] ?></strong> likes</div>

      <blockquote><?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>

      <small>
        — <?= htmlspecialchars($auteur, ENT_QUOTES, 'UTF-8') ?>
        • créée le <?= htmlspecialchars(date('d/m/Y', strtotime($c['created_at'])), ENT_QUOTES, 'UTF-8') ?>
        <?php if (!empty($c['updated_at'])): ?>
          • mise à jour le <?= htmlspecialchars(date('d/m/Y', strtotime($c['updated_at'])), ENT_QUOTES, 'UTF-8') ?>
        <?php endif; ?>
      </small>

      <div style="margin-top:10px;">
        <a href="/citation/my_citation_edit.php?id=<?= (int)$c['id'] ?>">Modifier</a>
        |
        <a href="/citation/my_citation_delete.php?id=<?= (int)$c['id'] ?>">Supprimer</a>
      </div>
    </article>
    <hr>
  <?php endforeach; ?>
<?php endif; ?>

<hr>

<h3>Mes likes</h3>

<?php if (!$likedCitations): ?>
  <p>Aucun like.</p>
<?php else: ?>
  <?php foreach ($likedCitations as $c): ?>
    <?php
      $auteur = trim((string)($c['auteur'] ?? ''));
      if ($auteur === '') $auteur = 'Auteur inconnu';
    ?>
    <article>
      <div><strong><?= (int)$c['likes_count'] ?></strong> likes</div>

      <blockquote><?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>

      <small>
        — <?= htmlspecialchars($auteur, ENT_QUOTES, 'UTF-8') ?>
        • liké le <?= htmlspecialchars(date('d/m/Y H:i', strtotime($c['liked_at'])), ENT_QUOTES, 'UTF-8') ?>
      </small>

      <div style="margin-top:10px;">
        <form method="post" action="/citation/like/unlike.php" style="display:inline;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="citation_id" value="<?= (int)$c['id'] ?>">
          <button type="submit">Unlike</button>
        </form>
      </div>
    </article>
    <hr>
  <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>

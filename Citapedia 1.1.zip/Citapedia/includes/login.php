<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

if (is_logged_in()) {
    header('Location: ' . (is_admin() ? '/admin/dashboard.php' : '/includes/profile.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = "Champs requis.";
    } else {
        $st = $pdo->prepare("
            SELECT id, nom_utilisateur, mot_de_passe, role
            FROM utilisateurs
            WHERE nom_utilisateur = :u
            LIMIT 1
        ");
        $st->execute([':u' => $username]);
        $user = $st->fetch();

        if ($user && password_verify($password, $user['mot_de_passe'])) {
            $_SESSION['user'] = [
                'id'       => (int)$user['id'],
                'username' => $user['nom_utilisateur'],
                'role'     => $user['role'],
            ];

            header('Location: ' . (($user['role'] ?? '') === 'admin' ? '/admin/dashboard.php' : '/includes/profile.php'));
            exit;
        }

        $error = "Identifiants invalides.";
    }
}

require_once __DIR__ . '/header.php';
?>

<h2>Connexion</h2>

<?php if ($error): ?>
    <p style="color:red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<form method="post">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

    <label>
        Nom d'utilisateur
        <input type="text" name="username" required>
    </label>
    <br><br>

    <label>
        Mot de passe
        <input type="password" name="password" required>
    </label>
    <br><br>

    <button type="submit">Se connecter</button>
</form>

<p><a href="/includes/register.php">Créer un compte</a></p>

<?php require_once __DIR__ . '/footer.php'; ?>

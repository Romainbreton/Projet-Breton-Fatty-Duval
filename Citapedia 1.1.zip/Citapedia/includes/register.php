<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

if (is_logged_in()) {
    header('Location: /index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $username  = trim($_POST['username'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if ($username === '' || $email === '' || $password === '' || $password2 === '') {
        $error = "Tous les champs sont obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Adresse email invalide.";
    } elseif ($password !== $password2) {
        $error = "Les mots de passe ne correspondent pas.";
    } elseif (mb_strlen($password) < 8) {
        $error = "Le mot de passe doit contenir au moins 8 caractères.";
    } else {
        $st = $pdo->prepare("
            SELECT id
            FROM utilisateurs
            WHERE nom_utilisateur = :u OR email = :e
            LIMIT 1
        ");
        $st->execute([':u' => $username, ':e' => $email]);

        if ($st->fetch()) {
            $error = "Nom d'utilisateur ou email déjà utilisé.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $st = $pdo->prepare("
                INSERT INTO utilisateurs (nom_utilisateur, email, mot_de_passe, role, created_at, updated_at)
                VALUES (:u, :e, :p, 'user', NOW(), NOW())
            ");
            $st->execute([':u' => $username, ':e' => $email, ':p' => $hash]);

            $success = "Compte créé. Tu peux maintenant te connecter.";
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<h2>Créer un compte</h2>

<?php if ($success): ?>
    <p style="color:green;"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></p>
    <p><a href="/includes/login.php">Aller à la connexion</a></p>
<?php else: ?>
    <?php if ($error): ?>
        <p style="color:red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

        <label>
            Nom d'utilisateur
            <input type="text" name="username" required>
        </label>
        <br><br>

        <label>
            Email
            <input type="email" name="email" required>
        </label>
        <br><br>

        <label>
            Mot de passe
            <input type="password" name="password" required>
        </label>
        <br><br>

        <label>
            Confirmer le mot de passe
            <input type="password" name="password2" required>
        </label>
        <br><br>

        <button type="submit">Créer le compte</button>
    </form>

    <p><a href="/includes/login.php">Retour à la connexion</a></p>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>

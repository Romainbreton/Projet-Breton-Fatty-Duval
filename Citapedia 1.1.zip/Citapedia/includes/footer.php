  </div>
</main>
<footer>
  <div class="container">
    <p>&copy; <?= date('Y') ?> Citapedia</p>
  </div>
</footer>

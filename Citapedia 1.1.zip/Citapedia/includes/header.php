<?php require_once __DIR__ . '/auth.php'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Citapedia</title>
  <link rel="stylesheet" href="/assets/css/style.css?v=1">
</head>
<body>
<header>
  <div class="container header-inner">
    <a class="brand" href="/index.php">
      <span class="brand-dot"></span>
      <span>Citapedia</span>
    </a>

    <nav>
      <a class="navlink" href="/index.php">Accueil</a>

      <?php if (is_logged_in()): ?>
        <a class="navlink" href="/includes/profile.php">Profil</a>
        <a class="navlink" href="/citation/my_citation_add.php">Ajouter</a>
        <?php if (is_admin()): ?>
          <a class="navlink" href="/admin/dashboard.php">Admin</a>
        <?php endif; ?>
        <a class="navlink" href="/includes/logout.php">Déconnexion</a>
      <?php else: ?>
        <a class="navlink" href="/includes/login.php">Connexion</a>
        <a class="navlink" href="/includes/register.php">Créer un compte</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<main>
  <div class="container">

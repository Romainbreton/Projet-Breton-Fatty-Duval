<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $st = $pdo->prepare("DELETE FROM citations WHERE id = :id");
        $st->execute([':id' => $id]);
    }
    header('Location: /admin/delete_citation.php');
    exit;
}

$st = $pdo->query("
  SELECT c.id, c.texte, c.auteur, c.created_at, COUNT(cl.id) AS likes_count
  FROM citations c
  LEFT JOIN citation_likes cl ON cl.citation_id = c.id
  GROUP BY c.id
  ORDER BY c.created_at DESC
");
$citations = $st->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<h2>Gérer / supprimer des citations</h2>

<?php if (!$citations): ?>
  <p>Aucune citation.</p>
<?php else: ?>
  <?php foreach ($citations as $c): ?>
    <?php
      $auteur = trim((string)($c['auteur'] ?? ''));
      if ($auteur === '') $auteur = 'Auteur inconnu';
    ?>
    <article>
      <div><strong><?= (int)$c['likes_count'] ?></strong> likes</div>
      <blockquote><?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>
      <small>
        ID <?= (int)$c['id'] ?> • <?= htmlspecialchars(date('d/m/Y', strtotime($c['created_at'])), ENT_QUOTES, 'UTF-8') ?>
        • <?= htmlspecialchars($auteur, ENT_QUOTES, 'UTF-8') ?>
      </small>

      <form method="post" onsubmit="return confirm('Supprimer cette citation ?');" style="margin-top:10px;">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
        <button type="submit">Supprimer</button>
      </form>
    </article>
    <hr>
  <?php endforeach; ?>
<?php endif; ?>

<p><a href="/admin/dashboard.php">Retour admin</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

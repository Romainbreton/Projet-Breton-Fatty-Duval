<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/header.php';

/* --- Requête simple : new, sans pagination (tu peux remettre tes tris ensuite) --- */
$st = $pdo->query("
  SELECT c.id, c.texte, c.auteur, c.created_at, COUNT(cl.id) AS likes_count
  FROM citations c
  LEFT JOIN citation_likes cl ON cl.citation_id = c.id
  GROUP BY c.id
  ORDER BY c.created_at DESC
");
$citations = $st->fetchAll();

/* Sécuriser la payload JS (et fallback Auteur inconnu côté front aussi) */
$payload = [];
foreach ($citations as $c) {
  $auteur = trim((string)($c['auteur'] ?? ''));
  if ($auteur === '') $auteur = 'Auteur inconnu';

  $payload[] = [
    'id' => (int)$c['id'],
    'texte' => (string)$c['texte'],
    'auteur' => $auteur,
    'created_at' => (string)$c['created_at'],
    'likes_count' => (int)($c['likes_count'] ?? 0),
  ];
}

/* Images de fond (locales) */
$bgImages = [
  '/assets/img/bg1.jpg',
  '/assets/img/bg2.jpg',
  '/assets/img/bg3.jpg',
  '/assets/img/bg4.jpg',
  '/assets/img/bg5.jpg',
];
?>

<div class="hero" id="hero">
  <div class="hero-inner">
    <div class="hero-topbar">
      <div class="badge">
        Carrousel • changement automatique toutes les 15s
      </div>

      <div class="controls">
        <button class="btn" id="prevBtn" type="button">Précédent</button>
        <button class="btn" id="nextBtn" type="button">Suivant</button>
      </div>
    </div>

    <div class="carousel-card" id="card">
      <p class="quote fade" id="quoteText"></p>

      <div class="meta">
        <div>
          <div class="author" id="quoteAuthor"></div>
          <div id="quoteDate"></div>
        </div>

        <div class="likes">
          <span id="quoteLikes"></span>
          <?php if (is_logged_in()): ?>
            <form method="post" action="/citation/like/like.php" id="likeForm" style="margin:0;">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
              <input type="hidden" name="citation_id" id="likeCitationId" value="">
              <button class="btn" type="submit" style="padding:8px 10px;">Like</button>
            </form>
            <form method="post" action="/citation/like/unlike.php" id="unlikeForm" style="margin:0; display:none;">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
              <input type="hidden" name="citation_id" id="unlikeCitationId" value="">
              <button class="btn" type="submit" style="padding:8px 10px;">Unlike</button>
            </form>
          <?php else: ?>
            <a class="btn" href="/includes/login.php" style="padding:8px 10px;">Connexion</a>
          <?php endif; ?>
        </div>
      </div>

      <div class="progress">
        <div id="progressBar"></div>
      </div>

      <div class="small-hint" id="hint"></div>
    </div>
  </div>
</div>

<script>
(function(){
  const citations = <?= json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const bgImages = <?= json_encode($bgImages, JSON_UNESCAPED_SLASHES) ?>;

  const hero = document.getElementById('hero');
  const quoteText = document.getElementById('quoteText');
  const quoteAuthor = document.getElementById('quoteAuthor');
  const quoteDate = document.getElementById('quoteDate');
  const quoteLikes = document.getElementById('quoteLikes');
  const card = document.getElementById('card');
  const progressBar = document.getElementById('progressBar');
  const hint = document.getElementById('hint');

  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');

  const likeForm = document.getElementById('likeForm');
  const unlikeForm = document.getElementById('unlikeForm');
  const likeCitationId = document.getElementById('likeCitationId');
  const unlikeCitationId = document.getElementById('unlikeCitationId');

  if (!citations.length) {
    quoteText.textContent = "Aucune citation pour le moment.";
    quoteAuthor.textContent = "";
    quoteDate.textContent = "";
    quoteLikes.textContent = "";
    hint.textContent = "Ajoute une citation depuis ton profil.";
    return;
  }

  let i = 0;
  let timer = null;
  let paused = false;

  function setHeroBg(url){
    hero.style.setProperty('--bg-url', `url("${url}")`);
    hero.style.setProperty('background-image', `url("${url}")`);
    // On utilise ::before pour le rendu : on met un style inline via CSS var
    hero.style.setProperty('--hero-bg', `url("${url}")`);
    hero.style.setProperty('position', 'relative');
    hero.style.setProperty('border-radius', '16px');

    // hack simple: on met la bg dans ::before via style attribute
    hero.style.setProperty('--bg', `url("${url}")`);
    hero.style.setProperty('background', 'transparent');
    hero.style.setProperty('overflow', 'hidden');
    hero.style.setProperty('minHeight', 'calc(100vh - 120px)');
    hero.style.setProperty('display', 'grid');
    hero.style.setProperty('placeItems', 'center');

    // On injecte directement dans ::before via un style tag local si nécessaire
    // (pour éviter de complexifier, on met background-image inline sur ::before via dataset)
    hero.dataset.bg = url;
    hero.style.setProperty('--bgImg', `url("${url}")`);
    // Le CSS ci-dessous utilise hero::before, donc on met un style inline dans head :
  }

  // Petite injection CSS pour piloter hero::before avec dataset
  const style = document.createElement('style');
  style.textContent = `.hero::before{ background-image: var(--bgImg); }`;
  document.head.appendChild(style);

  function formatDate(iso){
    // iso: "YYYY-MM-DD HH:MM:SS"
    // simple, stable côté navigateur
    const s = String(iso || '');
    if (!s.includes(' ')) return '';
    const [d] = s.split(' ');
    const [Y,M,D] = d.split('-');
    if (!Y || !M || !D) return '';
    return `${D}/${M}/${Y}`;
  }

  function restartProgress(){
    progressBar.style.transition = 'none';
    progressBar.style.width = '0%';
    // forcer reflow
    void progressBar.offsetWidth;
    progressBar.style.transition = 'width 15000ms linear';
    progressBar.style.width = '100%';
  }

  function render(){
    const c = citations[i];

    // animation douce
    quoteText.classList.remove('fade');
    void quoteText.offsetWidth;
    quoteText.classList.add('fade');

    quoteText.textContent = c.texte;
    quoteAuthor.textContent = c.auteur || 'Auteur inconnu';
    quoteDate.textContent = formatDate(c.created_at);
    quoteLikes.textContent = `${c.likes_count} likes`;

    // Maj des formulaires like/unlike si présents
    if (likeCitationId) likeCitationId.value = c.id;
    if (unlikeCitationId) unlikeCitationId.value = c.id;

    // image de fond: on tourne aussi, indépendamment de l’index si tu veux
    const bg = bgImages[i % bgImages.length];
    hero.style.setProperty('--bgImg', `url("${bg}")`);

    hint.textContent = `Citation ${i+1} / ${citations.length}`;
    restartProgress();
  }

  function next(){
    i = (i + 1) % citations.length;
    render();
  }

  function prev(){
    i = (i - 1 + citations.length) % citations.length;
    render();
  }

  function start(){
    stop();
    timer = setInterval(() => {
      if (!paused) next();
    }, 15000);
  }

  function stop(){
    if (timer) clearInterval(timer);
    timer = null;
  }

  prevBtn.addEventListener('click', () => { prev(); start(); });
  nextBtn.addEventListener('click', () => { next(); start(); });

  // Pause au survol pour “confort lecture”
  card.addEventListener('mouseenter', () => { paused = true; });
  card.addEventListener('mouseleave', () => { paused = false; });

  // initial
  render();
  start();
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

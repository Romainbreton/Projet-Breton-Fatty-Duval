<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/csrf.php';

require_login();
csrf_check();

$citationIdRaw = $_POST['citation_id'] ?? '';
if (!ctype_digit($citationIdRaw) || (int)$citationIdRaw <= 0) {
    http_response_code(400);
    die('citation_id invalide.');
}
$citationId = (int)$citationIdRaw;
$userId = (int)$_SESSION['user']['id'];

$st = $pdo->prepare("SELECT id FROM citations WHERE id = :id LIMIT 1");
$st->execute([':id' => $citationId]);
if (!$st->fetch()) {
    http_response_code(404);
    die('Citation introuvable.');
}

$st = $pdo->prepare("
  INSERT INTO citation_likes (citation_id, user_id)
  VALUES (:c, :u)
  ON DUPLICATE KEY UPDATE created_at = created_at
");
$st->execute([':c' => $citationId, ':u' => $userId]);

$redirect = $_SERVER['HTTP_REFERER'] ?? '/index.php';
header('Location: ' . $redirect);
exit;

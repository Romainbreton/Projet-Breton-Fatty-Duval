<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/csrf.php';

require_login();
csrf_check();

$citationIdRaw = $_POST['citation_id'] ?? '';
if (!ctype_digit($citationIdRaw) || (int)$citationIdRaw <= 0) {
    http_response_code(400);
    die('citation_id invalide.');
}
$citationId = (int)$citationIdRaw;
$userId = (int)$_SESSION['user']['id'];

$st = $pdo->prepare("DELETE FROM citation_likes WHERE citation_id=:c AND user_id=:u");
$st->execute([':c' => $citationId, ':u' => $userId]);

$redirect = $_SERVER['HTTP_REFERER'] ?? '/index.php';
header('Location: ' . $redirect);
exit;

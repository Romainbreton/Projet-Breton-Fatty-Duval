<?php
require_once __DIR__ . '/../../includes/db.php';

header('Content-Type: application/json; charset=utf-8');

$citationIdRaw = $_GET['citation_id'] ?? '';
if (!ctype_digit($citationIdRaw) || (int)$citationIdRaw <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'citation_id invalide']);
    exit;
}

$citationId = (int)$citationIdRaw;

$st = $pdo->prepare("SELECT COUNT(*) AS c FROM citation_likes WHERE citation_id = :id");
$st->execute([':id' => $citationId]);

echo json_encode(['ok' => true, 'likes' => (int)($st->fetch()['c'] ?? 0)]);

<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

require_login();

$userId = (int)$_SESSION['user']['id'];
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    die('ID invalide.');
}

if (is_admin()) {
    $st = $pdo->prepare("SELECT id, texte FROM citations WHERE id = :id LIMIT 1");
    $st->execute([':id' => $id]);
} else {
    $st = $pdo->prepare("SELECT id, texte FROM citations WHERE id = :id AND created_by = :uid LIMIT 1");
    $st->execute([':id' => $id, ':uid' => $userId]);
}

$citation = $st->fetch();
if (!$citation) {
    http_response_code(403);
    die("Accès refusé.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (is_admin()) {
        $st = $pdo->prepare("DELETE FROM citations WHERE id = :id");
        $st->execute([':id' => $id]);
    } else {
        $st = $pdo->prepare("DELETE FROM citations WHERE id = :id AND created_by = :uid");
        $st->execute([':id' => $id, ':uid' => $userId]);
    }

    header('Location: /includes/profile.php');
    exit;
}

require_once __DIR__ . '/../includes/header.php';
?>

<h2>Supprimer une citation</h2>

<p>Confirmer la suppression :</p>
<blockquote><?= htmlspecialchars($citation['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>

<form method="post" onsubmit="return confirm('Supprimer cette citation ?');">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
  <button type="submit">Supprimer</button>
</form>

<p><a href="/includes/profile.php">Annuler</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

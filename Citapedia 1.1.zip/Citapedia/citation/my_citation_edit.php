<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

require_login();

define('CITATION_TEXTE_MAX', 2000);
define('CITATION_AUTEUR_MAX', 255);

$userId = (int)$_SESSION['user']['id'];
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    die('ID invalide.');
}

if (is_admin()) {
    $st = $pdo->prepare("SELECT id, texte, auteur, created_by FROM citations WHERE id = :id LIMIT 1");
    $st->execute([':id' => $id]);
} else {
    $st = $pdo->prepare("SELECT id, texte, auteur, created_by FROM citations WHERE id = :id AND created_by = :uid LIMIT 1");
    $st->execute([':id' => $id, ':uid' => $userId]);
}

$citation = $st->fetch();
if (!$citation) {
    http_response_code(403);
    die("Accès refusé.");
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $texte = trim($_POST['texte'] ?? '');
    $auteurInput = trim($_POST['auteur'] ?? '');

    if ($texte === '') {
        $error = "Le texte est obligatoire.";
    } elseif (mb_strlen($texte) > CITATION_TEXTE_MAX) {
        $error = "Le texte dépasse la longueur maximale (" . CITATION_TEXTE_MAX . ").";
    } elseif ($auteurInput !== '' && mb_strlen($auteurInput) > CITATION_AUTEUR_MAX) {
        $error = "L'auteur dépasse la longueur maximale (" . CITATION_AUTEUR_MAX . ").";
    } else {
        $auteur = ($auteurInput === '') ? null : $auteurInput;

        if (is_admin()) {
            $st = $pdo->prepare("UPDATE citations SET texte=:t, auteur=:a, updated_at=NOW() WHERE id=:id");
            $st->bindValue(':id', $id, PDO::PARAM_INT);
        } else {
            $st = $pdo->prepare("UPDATE citations SET texte=:t, auteur=:a, updated_at=NOW() WHERE id=:id AND created_by=:uid");
            $st->bindValue(':id', $id, PDO::PARAM_INT);
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
        }

        $st->bindValue(':t', $texte, PDO::PARAM_STR);
        if ($auteur === null) $st->bindValue(':a', null, PDO::PARAM_NULL);
        else $st->bindValue(':a', $auteur, PDO::PARAM_STR);

        $st->execute();

        header('Location: /includes/profile.php');
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<h2>Modifier une citation</h2>

<?php if ($error): ?>
  <p style="color:red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<form method="post">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

  <label>
    Texte
    <br>
    <textarea name="texte" rows="6" required><?= htmlspecialchars($citation['texte'], ENT_QUOTES, 'UTF-8') ?></textarea>
  </label>

  <br><br>

  <label>
    Auteur
    <br>
    <input type="text" name="auteur" maxlength="255"
           value="<?= htmlspecialchars($citation['auteur'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
  </label>

  <br><br>

  <button type="submit">Mettre à jour</button>
</form>

<p><a href="/includes/profile.php">Retour</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

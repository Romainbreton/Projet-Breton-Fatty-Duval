<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/header.php';

$sql = "
SELECT c.texte, u.nom_utilisateur
FROM citations c
LEFT JOIN utilisateurs u ON u.id = c.created_by
ORDER BY c.created_at DESC
LIMIT 5
";

$citations = $pdo->query($sql)->fetchAll();
?>

<section class="citations">
    <?php foreach ($citations as $i => $c): ?>
        <article class="citation <?= $i === 0 ? 'active' : '' ?>">
            <blockquote>
                <?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?>
            </blockquote>
            <small>
                — <?= htmlspecialchars($c['nom_utilisateur'] ?? 'Anonyme', ENT_QUOTES, 'UTF-8') ?>
            </small>
        </article>
    <?php endforeach; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/header.php';

// On affiche aussi le nom du créateur si possible
$sql = "
SELECT c.id, c.texte, c.created_at, u.nom_utilisateur
FROM citations c
LEFT JOIN utilisateurs u ON u.id = c.created_by
ORDER BY c.created_at DESC
";

$stmt = $pdo->query($sql);
$citations = $stmt->fetchAll();
?>

<h2>Citations</h2>

<?php if (empty($citations)): ?>
    <p>Aucune citation pour le moment.</p>
<?php else: ?>
    <?php foreach ($citations as $c): ?>
        <article>
            <blockquote><?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>
            <small>
                Ajoutée le <?= htmlspecialchars(date('d/m/Y', strtotime($c['created_at'])), ENT_QUOTES, 'UTF-8') ?>
                <?php if (!empty($c['nom_utilisateur'])): ?>
                    — par <?= htmlspecialchars($c['nom_utilisateur'], ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
            </small>
        </article>
        <hr>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

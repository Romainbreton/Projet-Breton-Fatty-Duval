<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';

require_login();

$userId = (int)$_SESSION['user']['id'];
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    die('ID invalide.');
}

// Charger la citation seulement si elle appartient à l'utilisateur
$stmt = $pdo->prepare("
    SELECT id, texte
    FROM citations
    WHERE id = :id AND created_by = :uid
    LIMIT 1
");
$stmt->execute([':id' => $id, ':uid' => $userId]);
$citation = $stmt->fetch();

if (!$citation) {
    http_response_code(403);
    die("Accès refusé (citation introuvable ou non autorisée).");
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $texte = trim($_POST['texte'] ?? '');
    if ($texte === '') {
        $error = "Le texte est obligatoire.";
    } else {
        $stmt = $pdo->prepare("
            UPDATE citations
            SET texte = :t, updated_at = NOW()
            WHERE id = :id AND created_by = :uid
        ");
        $stmt->execute([':t' => $texte, ':id' => $id, ':uid' => $userId]);

        header('Location: /profile.php');
        exit;
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<h2>Modifier une citation</h2>

<?php if ($error): ?>
    <p style="color:red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<form method="post">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
    <label>
        Texte
        <br>
        <textarea name="texte" rows="6" required><?= htmlspecialchars($citation['texte'], ENT_QUOTES, 'UTF-8') ?></textarea>
    </label>
    <br><br>
    <button type="submit">Mettre à jour</button>
</form>

<p><a href="/profile.php">Retour</a></p>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

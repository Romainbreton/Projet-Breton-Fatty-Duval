<?php
// includes/footer.php
?>
</main>
<footer>
    <hr>
    <p>&copy; <?= date('Y') ?> Citapedia</p>
</footer>
</body>
</html>

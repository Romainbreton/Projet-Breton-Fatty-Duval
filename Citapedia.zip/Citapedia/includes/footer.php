</main>

<footer>
    <p>&copy; <?= date('Y') ?> Citapedia</p>
</footer>

<script>
/* ===== BACKGROUND ===== */
const bgImages = document.querySelectorAll(".background-carousel img");
let bgIndex = 0;

/* ===== CITATIONS ===== */
const citations = document.querySelectorAll(".citation");
let citIndex = 0;

setInterval(() => {
    // background
    bgImages[bgIndex].classList.remove("active");
    bgIndex = (bgIndex + 1) % bgImages.length;
    bgImages[bgIndex].classList.add("active");

    // citation
    citations[citIndex].classList.remove("active");
    citIndex = (citIndex + 1) % citations.length;
    citations[citIndex].classList.add("active");
}, 15000);
</script>

</body>
</html>

<?php
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Citapedia</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>

<body>

<div class="background-carousel">
    <img src="/assets/img/bg1.jpg" class="active">
    <img src="/assets/img/bg2.jpg">
    <img src="/assets/img/bg3.jpg">
    <img src="/assets/img/bg4.jpg" class="logo">

</div>

<header>
    <div class="header-bar">
        <img src="/assets/img/bg4.jpg" class="header-logo">

        <div class="header-text">
            <h1><a href="/index.php">Citapedia</a></h1>
            <nav>
                <a href="/index.php">Accueil</a>
                <?php if (is_logged_in()): ?>
                    | <a href="/profile.php">Profil</a>
                    | <a href="/logout.php">Déconnexion</a>
                <?php else: ?>
                    | <a href="/login.php">Connexion</a>
                    | <a href="/register.php">Créer un compte</a>
                <?php endif; ?>
            </nav>
        </div>
    </div>
</header>

<main>

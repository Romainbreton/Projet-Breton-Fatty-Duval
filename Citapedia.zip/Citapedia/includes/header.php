<?php
// includes/header.php
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Citapedia</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<header>
    <h1><a href="/index.php">Citapedia</a></h1>
<nav>
    <a href="/index.php">Accueil</a>

    <?php if (is_logged_in()): ?>
        | <a href="/profile.php">Profil</a>

        <?php if (is_admin()): ?>
            | <a href="/admin/dashboard.php">Admin</a>
        <?php endif; ?>

        | <a href="/logout.php">Déconnexion</a>

    <?php else: ?>
        | <a href="/login.php">Connexion</a>
        | <a href="/register.php">Créer un compte</a>
    <?php endif; ?>
</nav>

<?php if (is_logged_in()): ?>
    <p>Connecté : <?= htmlspecialchars($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?> 
    <hr>
</header>
<main>

<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';

require_login();

$userId = (int)$_SESSION['user']['id'];
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    die('ID invalide.');
}

// Vérifier que la citation appartient à l'utilisateur
$stmt = $pdo->prepare("
    SELECT id, texte
    FROM citations
    WHERE id = :id AND created_by = :uid
    LIMIT 1
");
$stmt->execute([':id' => $id, ':uid' => $userId]);
$citation = $stmt->fetch();

if (!$citation) {
    http_response_code(403);
    die("Accès refusé (citation introuvable ou non autorisée).");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $stmt = $pdo->prepare("DELETE FROM citations WHERE id = :id AND created_by = :uid");
    $stmt->execute([':id' => $id, ':uid' => $userId]);

    header('Location: /profile.php');
    exit;
}

require_once __DIR__ . '/includes/header.php';
?>

<h2>Supprimer une citation</h2>

<p>Confirmer la suppression de :</p>
<blockquote><?= htmlspecialchars($citation['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>

<form method="post">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
    <button type="submit">Supprimer</button>
</form>

<p><a href="/profile.php">Annuler</a></p>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

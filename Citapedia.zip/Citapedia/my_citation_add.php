<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';

require_login();

$userId = (int)$_SESSION['user']['id'];
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $texte = trim($_POST['texte'] ?? '');

    if ($texte === '') {
        $error = "Le texte est obligatoire.";
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO citations (texte, source_id, created_by, created_at, updated_at)
            VALUES (:t, NULL, :uid, NOW(), NOW())
        ");
        $stmt->execute([
            ':t' => $texte,
            ':uid' => $userId
        ]);

        header('Location: /profile.php');
        exit;
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<h2>Ajouter une citation</h2>

<?php if ($error): ?>
    <p style="color:red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<form method="post">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
    <label>
        Texte de la citation
        <br>
        <textarea name="texte" rows="6" required></textarea>
    </label>
    <br><br>
    <button type="submit">Enregistrer</button>
</form>

<p><a href="/profile.php">Retour</a></p>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

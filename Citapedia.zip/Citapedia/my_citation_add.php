<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';

require_login();

$userId = (int)$_SESSION['user']['id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $texte  = trim($_POST['texte'] ?? '');
    $auteur = trim($_POST['auteur'] ?? '');

    if ($texte === '') {
        $error = "Le texte est obligatoire.";
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO citations (texte, auteur, created_by, created_at, updated_at)
            VALUES (:t, :a, :uid, NOW(), NOW())
        ");
        $stmt->execute([
            ':t'   => $texte,
            ':a'   => $auteur ?: null,
            ':uid' => $userId
        ]);

        header('Location: /profile.php');
        exit;
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<h2>Ajouter une citation</h2>

<?php if ($error): ?>
    <p style="color:red;"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<form method="post">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

    <label>
        Texte de la citation
        <textarea name="texte" rows="5" required></textarea>
    </label>

    <br><br>

    <label>
        Auteur (optionnel)
        <input type="text" name="auteur">
    </label>

    <br><br>
    <button type="submit">Ajouter</button>
</form>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$userId = (int)$_SESSION['user']['id'];

// Citations de l'utilisateur connecté uniquement
$stmt = $pdo->prepare("
    SELECT id, texte, created_at, updated_at
    FROM citations
    WHERE created_by = :uid
    ORDER BY created_at DESC
");
$stmt->execute([':uid' => $userId]);
$citations = $stmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<h2>Profil</h2>

<p>Compte : <strong><?= htmlspecialchars($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8') ?></strong></p>
<p>Rôle : <strong><?= htmlspecialchars($_SESSION['user']['role'], ENT_QUOTES, 'UTF-8') ?></strong></p>

<hr>

<h3>Mes citations</h3>

<p>
    <a href="/my_citation_add.php">Ajouter une citation</a>
</p>

<?php if (empty($citations)): ?>
    <p>Tu n'as encore ajouté aucune citation.</p>
<?php else: ?>
    <?php foreach ($citations as $c): ?>
        <article>
            <blockquote><?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>
            <small>
                ID <?= (int)$c['id'] ?> —
                Créée le <?= htmlspecialchars(date('d/m/Y', strtotime($c['created_at'])), ENT_QUOTES, 'UTF-8') ?>
                <?php if (!empty($c['updated_at'])): ?>
                    — Mise à jour le <?= htmlspecialchars(date('d/m/Y', strtotime($c['updated_at'])), ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
            </small>
            <div style="margin-top:10px;">
                <a href="/my_citation_edit.php?id=<?= (int)$c['id'] ?>">Modifier</a>
                |
                <a href="/my_citation_delete.php?id=<?= (int)$c['id'] ?>">Supprimer</a>
            </div>
        </article>
        <hr>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

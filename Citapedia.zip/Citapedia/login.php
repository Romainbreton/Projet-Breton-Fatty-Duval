<?php
// login.php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';

// Si déjà connecté : rediriger selon le rôle (évite les boucles)
if (is_logged_in()) {
    if (is_admin()) {
        header('Location: /admin/dashboard.php');
    } else {
        header('Location: /profile.php');
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = "Champs requis.";
    } else {
        $stmt = $pdo->prepare("
            SELECT id, nom_utilisateur, mot_de_passe, role
            FROM utilisateurs
            WHERE nom_utilisateur = :u
            LIMIT 1
        ");
        $stmt->execute([':u' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['mot_de_passe'])) {
            $_SESSION['user'] = [
                'id'       => (int)$user['id'],
                'username' => $user['nom_utilisateur'],
                'role'     => $user['role'],
            ];

            // Redirection selon le rôle
            if (($user['role'] ?? '') === 'admin') {
                header('Location: /admin/dashboard.php');
            } else {
                header('Location: /profile.php');
            }
            exit;
        }

        $error = "Identifiants invalides.";
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<h2>Connexion</h2>

<?php if ($error): ?>
    <p style="color:red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<form method="post" action="">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

    <label>
        Nom d'utilisateur
        <input type="text" name="username" required>
    </label>
    <br><br>

    <label>
        Mot de passe
        <input type="password" name="password" required>
    </label>
    <br><br>

    <button type="submit">Se connecter</button>
</form>

<p><a href="/register.php">Créer un compte</a></p>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

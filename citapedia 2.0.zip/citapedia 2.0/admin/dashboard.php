<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

require_once __DIR__ . '/../includes/header.php';
?>

<h2>Administration</h2>

<ul>
    <li><a href="/admin/add_citation.php">Ajouter une citation</a></li>
    <a href="./delete_citation.php?id=<?= (int)$citation['id'] ?>">Gérer / supprimer des ciatations</a>
</ul>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

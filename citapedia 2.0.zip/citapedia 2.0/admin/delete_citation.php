<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

require_admin();

// Suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $pdo->prepare("DELETE FROM citations WHERE id = :id");
        $stmt->execute([':id' => $id]);
    }

    header('Location: /admin/citations.php');
    exit;
}

// Liste
$stmt = $pdo->query("
    SELECT c.id, c.texte, c.created_at, u.nom_utilisateur
    FROM citations c
    LEFT JOIN utilisateurs u ON u.id = c.created_by
    ORDER BY c.created_at DESC
");
$citations = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<h2>Gérer les citations</h2>

<?php if (empty($citations)): ?>
    <p>Aucune citation.</p>
<?php else: ?>
    <?php foreach ($citations as $c): ?>
        <article>
            <blockquote><?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>
            <small>
                ID <?= (int)$c['id'] ?> —
                <?= htmlspecialchars(date('d/m/Y', strtotime($c['created_at'])), ENT_QUOTES, 'UTF-8') ?>
                <?php if (!empty($c['nom_utilisateur'])): ?>
                    — par <?= htmlspecialchars($c['nom_utilisateur'], ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
            </small>

            <form method="post" action="" onsubmit="return confirm('Supprimer cette citation ?');">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                <button type="submit">Supprimer</button>
            </form>
        </article>
        <hr>
    <?php endforeach; ?>
<?php endif; ?>

<p><a href="/admin/dashboard.php">Retour admin</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

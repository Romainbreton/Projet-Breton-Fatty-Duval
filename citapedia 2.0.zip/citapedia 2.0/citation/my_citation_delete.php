<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

csrf_check();

$userId = (int)$_SESSION['user']['id'];
$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    exit('ID invalide.');
}

// Un user normal ne peut supprimer QUE ses citations.
// Un admin peut tout supprimer (si tu veux l’autoriser).
if (is_admin()) {
    $st = $pdo->prepare("DELETE FROM citations WHERE id = :id");
    $st->execute([':id' => $id]);
} else {
    $st = $pdo->prepare("DELETE FROM citations WHERE id = :id AND created_by = :uid");
    $st->execute([':id' => $id, ':uid' => $userId]);
}

header('Location: /includes/profile.php');
exit;

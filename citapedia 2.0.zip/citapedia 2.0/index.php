<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/header.php';

$userId = is_logged_in() ? (int)($_SESSION['user']['id'] ?? 0) : 0;

/*
  Liste des citations + compteur de likes.
  Si connecté, on récupère aussi si l'utilisateur a liké (liked_by_me).
*/
if ($userId > 0) {
  $st = $pdo->prepare("
    SELECT
      c.id,
      c.texte,
      COALESCE(NULLIF(TRIM(c.auteur), ''), 'Auteur inconnu') AS auteur,
      c.created_at,
      COUNT(cl.id) AS likes_count,
      SUM(CASE WHEN cl.user_id = :uid THEN 1 ELSE 0 END) AS liked_by_me
    FROM citations c
    LEFT JOIN citation_likes cl ON cl.citation_id = c.id
    GROUP BY c.id
    ORDER BY c.created_at DESC
  ");
  $st->execute([':uid' => $userId]);
  $citations = $st->fetchAll();
} else {
  $st = $pdo->query("
    SELECT
      c.id,
      c.texte,
      COALESCE(NULLIF(TRIM(c.auteur), ''), 'Auteur inconnu') AS auteur,
      c.created_at,
      COUNT(cl.id) AS likes_count,
      0 AS liked_by_me
    FROM citations c
    LEFT JOIN citation_likes cl ON cl.citation_id = c.id
    GROUP BY c.id
    ORDER BY c.created_at DESC
  ");
  $citations = $st->fetchAll();
}
?>

<section class="hero">
  <div class="carousel" data-carousel="true" data-interval="15000">
    <div class="carousel-slide" style="display:block;">
      <img src="./assets/img/bg1.jpg" alt="">
    </div>

    <div class="carousel-slide" style="display:none;">
      <img src="./assets/img/bg2.jpg" alt="">
    </div>

    <div class="carousel-slide" style="display:none;">
      <img src="./assets/img/img1.jpg" alt="">
    </div>

    <div class="carousel-slide" style="display:none;">
      <img src="./assets/img/img2.jpg" alt="">
    </div>

    <div class="carousel-slide" style="display:none;">
      <img src="./assets/img/fond.jpg" alt="">
    </div>

    <div class="carousel-dots">
      <button type="button" class="carousel-dot"></button>
      <button type="button" class="carousel-dot"></button>
      <button type="button" class="carousel-dot"></button>
      <button type="button" class="carousel-dot"></button>
      <button type="button" class="carousel-dot"></button>
    </div>
  </div>
</section>


  <h2>Dernières citations</h2>

  <?php if (empty($citations)): ?>
    <p>Aucune citation pour le moment.</p>
  <?php else: ?>
    <?php foreach ($citations as $c): ?>
      <article style="margin: 18px 0;">
        <blockquote><?= htmlspecialchars($c['texte'], ENT_QUOTES, 'UTF-8') ?></blockquote>
        <small>
          Ajoutée le <?= htmlspecialchars(date('d/m/Y', strtotime($c['created_at'])), ENT_QUOTES, 'UTF-8') ?>
          — <?= htmlspecialchars($c['auteur'], ENT_QUOTES, 'UTF-8') ?>
        </small>

        <div style="margin-top: 10px;">
          <strong><?= (int)$c['likes_count'] ?></strong> like<?= ((int)$c['likes_count'] === 1) ? '' : 's' ?>

          <?php if (is_logged_in()): ?>
            <?php if ((int)$c['liked_by_me'] > 0): ?>
              <form method="post" action="/citation/like/unlike.php" style="display:inline;">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="citation_id" value="<?= (int)$c['id'] ?>">
                <button type="submit">Je n'aime plus</button>
              </form>
            <?php else: ?>
              <form method="post" action="/citation/like/like.php" style="display:inline;">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="citation_id" value="<?= (int)$c['id'] ?>">
                <button type="submit">J'aime</button>
              </form>
            <?php endif; ?>
          <?php else: ?>
            <span>— <a href="/includes/login.php">Connecte-toi</a> pour liker</span>
          <?php endif; ?>
        </div>
      </article>
      <hr>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

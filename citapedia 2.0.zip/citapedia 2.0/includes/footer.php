</main>
<footer>
  <hr>
  <p>&copy; <?= date('Y') ?> Citapedia</p>
</footer>

<script src="./assets/js/carousel.js" defer></script>
</body>
</html>

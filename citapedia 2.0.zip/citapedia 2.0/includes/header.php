<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Citapedia</title>
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<header>
  <h1><a href="/index.php">Citapedia</a></h1>

  <nav>
    <a href="/index.php">Accueil</a>

    <?php if (is_logged_in()): ?>
      <a href="/includes/profile.php">Profil</a>
      <a href="/citation/my_citation_add.php">Ajouter une citation</a>
      <?php if (is_admin()): ?>
        <a href="/admin/dashboard.php">Admin</a>
      <?php endif; ?>
      <a href="/includes/logout.php">Déconnexion</a>
    <?php else: ?>
      <a href="/includes/login.php">Connexion</a>
      <a href="/includes/register.php">Créer un compte</a>
    <?php endif; ?>
  </nav>

  <hr>
</header>

<main>

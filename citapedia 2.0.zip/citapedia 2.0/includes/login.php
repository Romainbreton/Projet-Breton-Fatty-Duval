<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

if (is_logged_in()) {
    header('Location: ' . (is_admin() ? '/admin/dashboard.php' : '/includes/profile.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $error = 'Veuillez remplir tous les champs.';
    } else {
        $st = $pdo->prepare('SELECT id, nom_utilisateur, mot_de_passe, role FROM utilisateurs WHERE nom_utilisateur = :u');
        $st->execute([':u' => $username]);
        $user = $st->fetch();

        if ($user && password_verify($password, (string)$user['mot_de_passe'])) {
            $_SESSION['user'] = [
                'id'       => (int)$user['id'],
                'username' => (string)$user['nom_utilisateur'],
                'role'     => (string)($user['role'] ?? ''),
            ];

            header('Location: ' . (((string)($user['role'] ?? '')) === 'admin' ? '/admin/dashboard.php' : '/includes/profile.php'));
            exit;
        }

        $error = 'Identifiants invalides.';
    }
}

require_once __DIR__ . '/header.php';
?>

<h2>Connexion</h2>

<?php if ($error): ?>
  <p style="color:#b91c1c;"><strong><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></strong></p>
<?php endif; ?>

<form method="post" action="/includes/login.php">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

  <label for="username">Nom d'utilisateur</label><br>
  <input id="username" name="username" type="text" required><br><br>

  <label for="password">Mot de passe</label><br>
  <input id="password" name="password" type="password" required><br><br>

  <button type="submit">Se connecter</button>
</form>

<p style="margin-top:12px;">
  Pas de compte ? <a href="/includes/register.php">Créer un compte</a>
</p>

<?php require_once __DIR__ . '/footer.php'; ?>

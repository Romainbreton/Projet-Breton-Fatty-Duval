<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

require_login();

$userId = (int)$_SESSION['user']['id'];

// Mes citations (uniquement celles créées par moi)
$st = $pdo->prepare("
    SELECT id, texte, auteur, created_at, updated_at
    FROM citations
    WHERE created_by = :uid
    ORDER BY id DESC
");
$st->execute([':uid' => $userId]);
$citations = $st->fetchAll();

require_once __DIR__ . '/header.php';
?>

<h2>Mon profil</h2>

<p>
  Connecté en tant que :
  <strong><?= htmlspecialchars($_SESSION['user']['nom_utilisateur'] ?? 'Utilisateur', ENT_QUOTES, 'UTF-8') ?></strong>
</p>

<hr>

<h3>Mes citations</h3>

<?php if (!$citations): ?>
  <p>Aucune citation pour le moment.</p>
<?php else: ?>
  <?php foreach ($citations as $c): ?>
    <article style="margin-bottom:16px; padding:12px; border:1px solid #eee; border-radius:10px;">
      <blockquote style="margin-bottom:8px;">
        <?= nl2br(htmlspecialchars($c['texte'] ?? '', ENT_QUOTES, 'UTF-8')) ?>
      </blockquote>

      <small>
        Auteur :
        <strong><?= htmlspecialchars($c['auteur'] ?? '—', ENT_QUOTES, 'UTF-8') ?></strong>
        • ID :
        <strong><?= (int)$c['id'] ?></strong>
        • Créée le :
        <?= htmlspecialchars($c['created_at'] ?? '', ENT_QUOTES, 'UTF-8') ?>
      </small>

      <div style="margin-top:10px; display:flex; gap:10px; align-items:center;">
        <!-- IMPORTANT: on passe bien ?id=... -->
        <a href="/citation/my_citation_edit.php?id=<?= (int)$c['id'] ?>">Modifier</a>

        <!-- Suppression en POST + CSRF -->
        <form method="post" action="/citation/my_citation_delete.php" onsubmit="return confirm('Supprimer cette citation ?');" style="display:inline;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
          <button type="submit">Supprimer</button>
        </form>
      </div>
    </article>
  <?php endforeach; ?>
<?php endif; ?>

<hr>

<p>
  <a href="/">Retour accueil</a>
</p>

<?php require_once __DIR__ . '/footer.php'; ?>

<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

if (is_logged_in()) {
    header('Location: /includes/profile.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password2'] ?? '');

    if ($username === '' || $password === '' || $password2 === '') {
        $error = 'Veuillez remplir tous les champs.';
    } elseif ($password !== $password2) {
        $error = 'Les mots de passe ne correspondent pas.';
    } elseif (mb_strlen($username) < 3) {
        $error = "Le nom d'utilisateur doit faire au moins 3 caractères.";
    } else {
        $st = $pdo->prepare('SELECT id FROM utilisateurs WHERE nom_utilisateur = :u');
        $st->execute([':u' => $username]);
        if ($st->fetch()) {
            $error = "Ce nom d'utilisateur est déjà pris.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $st = $pdo->prepare('INSERT INTO utilisateurs (nom_utilisateur, mot_de_passe, role) VALUES (:u, :p, :r)');
            $st->execute([
                ':u' => $username,
                ':p' => $hash,
                ':r' => 'user',
            ]);

            $success = 'Compte créé. Vous pouvez vous connecter.';
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<h2>Créer un compte</h2>

<?php if ($error): ?>
  <p style="color:#b91c1c;"><strong><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></strong></p>
<?php endif; ?>

<?php if ($success): ?>
  <p style="color:#047857;"><strong><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></strong></p>
<?php endif; ?>

<form method="post" action="/includes/register.php">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

  <label for="username">Nom d'utilisateur</label><br>
  <input id="username" name="username" type="text" required><br><br>

  <label for="password">Mot de passe</label><br>
  <input id="password" name="password" type="password" required><br><br>

  <label for="password2">Confirmer le mot de passe</label><br>
  <input id="password2" name="password2" type="password" required><br><br>

  <button type="submit">Créer le compte</button>
</form>

<p style="margin-top:12px;">
  Déjà un compte ? <a href="/includes/login.php">Connexion</a>
</p>

<?php require_once __DIR__ . '/footer.php'; ?>

console.log("CAROUSEL JS OK");

(function () {
  function initCarousel(root) {
    const slides = Array.from(root.querySelectorAll(".carousel-slide"));
    const dots = Array.from(root.querySelectorAll(".carousel-dot"));
    if (slides.length === 0) return;

    const interval = Number(root.getAttribute("data-interval")) || 15000;
    let index = 0;
    let timer = null;

    // Hardening: ensure container behaves like a carousel even if CSS missing
    root.style.position = "relative";
    root.style.overflow = "hidden";

    function show(i) {
      index = (i + slides.length) % slides.length;

      slides.forEach((s, k) => {
        const active = k === index;

        // KEY FIX: hide others completely (no stacking)
        s.style.display = active ? "block" : "none";

        // Optional: if you still want fade when CSS is present
        s.classList.toggle("is-active", active);

        s.setAttribute("aria-hidden", active ? "false" : "true");
      });

      dots.forEach((d, k) => {
        const active = k === index;
        d.classList.toggle("is-active", active);
        d.setAttribute("aria-current", active ? "true" : "false");
      });
    }

    function start() {
      stop();
      timer = setInterval(() => show(index + 1), interval);
    }

    function stop() {
      if (timer) clearInterval(timer);
      timer = null;
    }

    dots.forEach((d, i) => {
      d.addEventListener("click", () => {
        show(i);
        start();
      });
    });

    root.addEventListener("mouseenter", stop);
    root.addEventListener("mouseleave", start);

    show(0);
    start();
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-carousel='true']").forEach(initCarousel);
  });
})();
